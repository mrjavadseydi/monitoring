<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Uploads extends Model
{
    //
//    public function actions(){
//        return $this->morphOne('app/Models/Actions');
//    }
}
